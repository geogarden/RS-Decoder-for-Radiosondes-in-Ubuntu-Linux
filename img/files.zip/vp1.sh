#!/bin/sh

echo "Creating Virtual Com Port: 0 and 1"

socat -d -d pty,link=/tmp/virtualcom0,raw,echo=0 pty,link=/tmp/virtualcom1,raw,b4800,echo=0

sleep 2
