#!/bin/sh

xfce4-terminal -T vp1 -e ./vp1.sh --tab -T vp2 -e ./vp2.sh --tab -T vp3 -e ./vp3.sh --tab -T dfm -e ./dfm.sh
