#!/bin/bash

sox -t pulseaudio default -t wav - 2>/dev/null | ./rs41mod --ecc2 --crc -vx --ptu 2>&1 | tee -a /home/decoders/rs41_`date +%Y%m%d%H`Z.txt  | ./pos2nmea.pl > /tmp/virtualcom0

exit
