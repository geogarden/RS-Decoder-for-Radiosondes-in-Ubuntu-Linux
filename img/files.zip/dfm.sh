#!/bin/bash

sox -t pulseaudio default -t wav - 2>/dev/null | ./dfm09mod --dist -vv --ptu --auto 2>&1 | tee -a /home/decoders/dfm09_`date +%Y%m%d%H`Z.txt | ./pos2nmea.pl > /tmp/virtualcom0

exit
